# V. Subbaiya Tiffins Android App

A first Android version for V. Subbaiya Tiffins, built as a small WebView app.

Features:
- Tamil + English menu
- WhatsApp order: 6380797708
- Call button
- Google Maps link
- Gold + black restaurant theme
- Menu prices from the supplied menu card

## Build on GitHub Actions
1. Create a GitHub repository and upload this project.
2. Push to the `main` branch.
3. Open Actions -> Build Android APK -> run it if needed.
4. Download the `VSubbaiyaTiffins-debug-apk` artifact.

This debug APK is for testing. A Play Store release requires a properly signed release AAB and Play Console setup.
