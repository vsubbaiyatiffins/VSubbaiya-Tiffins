plugins {
    id("com.android.application")
}

android {
    namespace = "com.vsubbaiya.tiffins"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vsubbaiya.tiffins"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            minifyEnabled = false
            shrinkResources = false
        }
    }
}
